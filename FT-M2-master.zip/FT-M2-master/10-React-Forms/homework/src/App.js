import React from 'react';
import logo from './logo.svg';
import Form from './Form.jsx';

function App() {
  return (
    <Form />
  );
}

export default App;
