import React from 'react';

export default function  Form() {
  return (
      <div>
        Componente Form
      </div>
  )
}
