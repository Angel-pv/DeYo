import React from 'react';

const Timer = () => {
  return (
    <div className="app">
      Componente Timer
    </div>
  );
};

export default Timer;
