export const saveName = (payload) => {
  return { type: 'SAVE_NAME', payload };
};