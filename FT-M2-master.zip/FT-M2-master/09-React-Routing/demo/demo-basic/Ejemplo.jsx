import React from 'react';

export default function Ejemplo({nombre, apellido}) {
    return (
        <h1>{`Hola soy: ${nombre}, ${apellido}`}</h1>
    )
};