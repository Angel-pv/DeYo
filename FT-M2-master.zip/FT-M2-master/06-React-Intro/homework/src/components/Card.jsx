import React from 'react';

export default function Card(props) {
  // acá va tu código
  return <div>Card Component</div>
};