import React from 'react';

export default function Cards(props) {
  // acá va tu código
  // tip, podés usar un map
  return <div>Cards Component</div>
};