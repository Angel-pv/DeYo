/* 
  Importante: 
  No modificar ni el nombre ni los argumetos que reciben las funciones, sólo deben escribir
  código dentro de las funciones ya definidas. 
  No comentar la funcion 
*/
function sumaTodosPrimos(array) {
  // La funcion llamada 'sumaTodosPrimos' recibe como argumento un array de enteros.
  // y debe devolver la suma total entre todos los numeros que sean primos.
  // Pista: un número primo solo es divisible por sí mismo y por 1
  // Nota: Los números 0 y 1 NO son considerados números primos
  // Ej:
  // sumaTodosPrimos([1, 5, 2, 9, 3, 4, 11]) devuelve 5 + 2 + 3 + 11 = 21
  // Nota: Podes usar la funcion 'esPrimo' resuelta en la homework JSII.

  // Tu código aca:

  let noEsPrimo = [];
  let nuevoArray = [];
  let suma = 0;

  for (var i = 0; i < array.length; i++) {
    if (array[i] < 2) {
      noEsPrimo.push(array[i]);
    } else if (array[i] === 2 || array[i] === 5) {
      nuevoArray.push(array[i]);
    } else if (array[i] % i === 0 || array[i] % 5 === 0 || array[i] % 2 === 0) {
      noEsPrimo.push(array[i]);
    } else {
      nuevoArray.push(array[i]);
    }
  }

  for (var i = 0; i < nuevoArray.length; i++) {
    suma += nuevoArray[i];
  }
return suma;
}





// No modifiques nada debajo de esta linea //

module.exports = sumaTodosPrimos