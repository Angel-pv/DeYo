## Show Image by Name

Vamos a mostrar cada una de las imagenes que se encuentran en la carpeta `images` cuando la ruta tenga su mismo nombre.

* Crea un nuevo servidor que usando el path del url muestre la imagen con el mismo nombre. ¿Qué tipo de "Content-Type" deberiamos usar?

* Si no hay ninguna imagen con ese nombre debería aparecer un mensaje de error
