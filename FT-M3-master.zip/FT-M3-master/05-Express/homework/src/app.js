const { server } = require('./server.js');

server.listen(3000);
