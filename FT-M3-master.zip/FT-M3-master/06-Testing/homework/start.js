const server = require('./index.js');

server.listen(3000, () => {
  console.log('Server listening in port 3000');
})