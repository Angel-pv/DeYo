const moment = require('moment');

console.log(moment().format("MMMM d YYYY"))



