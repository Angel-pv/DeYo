
var hola = 'toni';
var guido = 21;

console.log('saludos');


module.exports = {
    hola: hola,
    guido: guido,
}
