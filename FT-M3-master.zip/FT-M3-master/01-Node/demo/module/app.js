// var hola = require('./hola.js');
//saludar();

var s = require('./saludos/');

var util = require('util'); 

console.log(util.format('Hola, %s, como estas? %s', 'Toni', 'das'));