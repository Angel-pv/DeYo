var saludoEN = function () {
  console.log('Hi')
}

const hola = 1;

module.exports = saludoEN;