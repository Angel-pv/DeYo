var saludoEn = require('./en.js');
var saludoEs = require('./es.js');


module.exports = {
  en : saludoEn,
  es : saludoEs
}
