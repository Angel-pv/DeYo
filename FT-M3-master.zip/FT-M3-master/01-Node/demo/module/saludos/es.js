module.exports = function saludoEn() {
  console.log('Hola');
}
