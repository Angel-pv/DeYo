
function ejemplo(hola) {
  console.log(hola);
}

ejemplo(1);
ejemplo('toni');
ejemplo(3);

