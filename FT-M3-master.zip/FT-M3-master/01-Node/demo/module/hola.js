//console.log('Hola!');

var saludar = function() {
	console.log('Hola!!!');
}
//saludar();
module.exports = saludar;