var saludos = require('./saludos');

saludos.english();
saludos.spanish();