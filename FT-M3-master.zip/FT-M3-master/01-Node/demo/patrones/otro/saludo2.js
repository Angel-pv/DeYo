module.exports.saludo = function() {
	console.log('Hola mundo 2!');
};

// Aquí hemos agregados una propiedad al objeto module.exports
// con una función anónima que saluda
// Vamos a app.js par ver cómo se utiliza.