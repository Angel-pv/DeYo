module.exports = function() {
	console.log('Hola mundo');
};

// Esta es la forma que conociamos!