function fizzBuzzGenerator(max) {
  // Tu código acá:

}

module.exports = fizzBuzzGenerator;
