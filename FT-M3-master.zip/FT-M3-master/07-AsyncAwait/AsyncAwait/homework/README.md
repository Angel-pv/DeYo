# Async Await Homework

Esta homework consiste en modificar los archivos `exercise-one.js` y `exercise-one.js` para pasar de tener la solución utilizando callbacks a tenerla usando async await. Es equivalente a cuando realizaron la conversión a Promises pero ahora pensandolo desde el punto de vista de async await.

Recordar modificar el `xit` por `it` en los tests para ir corriendo el test que deseen.
