import React from 'react';

  // FIJENSE DE HACERLO SI O SI CON FUNCTIONAL COMPONENT! SI NO LOS TEST NO PASAN.


const ProductCard = () => {
  
  return (
    <div>
     Product Card
    </div>
  );
};

export default ProductCard;