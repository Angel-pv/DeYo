import React from "react";
import { Route } from "react-router-dom";
import Houses from "./components/Houses/Houses";
import Nav from "./components/Nav/Nav";
import HouseDetail from "./components/HouseDetail/HouseDetail";
import CreateHouse from "./components/CreateHouse/CreateHouse";

function App() {
  return (
    <div className="App">
      <React.Fragment>
        <Nav/>
        <Route exact path='/' component={Houses} />
        <Route exact path='/houses/:houseId' component={HouseDetail} />
        <Route exact path='/house/create' component={CreateHouse} />
      </React.Fragment>
    </div>
  );
}

export default App;
