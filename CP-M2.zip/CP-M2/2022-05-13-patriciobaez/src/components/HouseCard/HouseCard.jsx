import React, { Component } from 'react';
import { connect } from 'react-redux';
import { Link } from 'react-router-dom';
import { deleteHouse } from '../../redux/actions';

// CUIDADOOOO. SI O SI CLASS COMPONENT! SE ROMPEN LOS TEST EN CASO CONTRARIO!!
// TAMBIEN VAS A TENER QUE USAR EL METODO CONNECT DE REDUX , JUNTO A MAP_DISPATCH_TO_PROPS! <3
export class HouseCard extends Component {
    constructor(props){
        super(props);
        this.state = {
            id: props.id,
            region: props.region,
            name: props.name,
            words: props.words
        }
    }

    render() {

        return (
            <div>
                <button onClick={() => this.props.deleteHouse(this.state.id)}></button>
                <h3>{this.state.name}</h3>
                <p>Region: {this.state.region}</p>
                <p>Words: {this.state.words}</p>
                <Link to={`/houses/${this.state.id}`}>{this.state.name}</Link>
            </div>
        );
    };
};

export function mapDispatchToProps(dispatch) {
    mapDispatchToProps = {
        deleteHouse: id => dispatch(deleteHouse(id))
    }
    return mapDispatchToProps
};
export default connect(null, mapDispatchToProps)(HouseCard);
