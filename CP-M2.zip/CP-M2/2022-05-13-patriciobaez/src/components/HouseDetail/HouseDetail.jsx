import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { getHouse } from '../../redux/actions';
import CharacterCard from '../CharacterCard/CharacterCard';

// CUIDADOOOO. SI O SI FUNCTIONAL COMPONENT! SE ROMPEN LOS TEST EN CASO CONTRARIO!!
// TAMBIEN VAS A TENER QUE USAR HOOKS!
const HouseDetail = (props) => {

  const dispatch = useDispatch()
  React.useEffect(() =>{
    dispatch(getHouse(props.match.params.houseId))}, [])

  const house = useSelector(state => state.house)
  return (
      <div>
        <p>{house.name}</p>
        <p>{house.words}</p>
        {house.characters && house.characters.map(character => 
          <div key={character.id}>
            <CharacterCard fullName={character.fullName} id={character.id} family={character.family} title={character.title} imageUrl={character.imageUrl} houseid={character.houseId} />
          </div>
          )}
      </div>
  );
};

export default HouseDetail;
