import React from "react";
import { useDispatch } from "react-redux";
import { createHouse } from "../../redux/actions";

// CUIDADOOOO. SI O SI FUNCTIONAL COMPONENT! SE ROMPEN LOS TEST EN CASO CONTRARIO!!
// TAMBIEN VAS A TENER QUE USAR HOOKS!
// Recordar que los hooks de React deben utilizarse de la forma "React.useState", "React.useEffect", etc.
// Los tests no van a reconocer la ejecución haciendo destructuring de estos métodos.
const CreateHouse = () => {
  const [state, setState] = React.useState({name: "", region: "", words: ""})
  const dispatch = useDispatch()
  const handlechange = (event) => {
    setState({
      ...state,
      [event.target.name]: event.target.value
    })
  }
  const handlesubmit = (event) => {
    event.preventDefault(),
    dispatch(createHouse(state))
  }

  return (
    <div>
      <form onSubmit={(event) => handlesubmit(event)}>
        <label>Name: </label>
        <input name='name' onChange={handlechange}></input>
        <label>Region: </label>
        <input name='region' onChange={handlechange}></input>
        <label>Words: </label>
        <input name='words' onChange={handlechange}></input>
        <button type="submit">Create</button>
      </form>
    </div>
  );
};

export default CreateHouse;
